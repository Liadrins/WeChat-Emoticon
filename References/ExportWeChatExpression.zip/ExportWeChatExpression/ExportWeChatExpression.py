#coding = utf8
import os,_winreg,binascii,shutil

def isInstallWeChat():
    try:
        userInstallPath = ""
        if(os.path.exists(os.path.expandvars(r"%appdata%\Tencent\WeChat\All Users\config"))):
            pathDir = os.listdir(os.path.expandvars(r"%appdata%\Tencent\WeChat\All Users\config"))
            for allDir in pathDir:
                if(allDir.endswith(".ini")):
                    if(open(os.path.expandvars(r"%appdata%\Tencent\WeChat\All Users\config/")+allDir,"r").read() == "MyDocument:"):
                        userInstallPath = os.path.expandvars(_winreg.QueryValueEx(_winreg.OpenKey(_winreg.HKEY_CURRENT_USER,r"Software\Microsoft\Windows\CurrentVersion\Explorer\User Shell Folders"),"Personal")[0])
                    else:
                        if(open(os.path.expandvars(r"%appdata%\Tencent\WeChat\All Users\config/")+allDir,"r").read()[1] == ":"):
                            userInstallPath = open(os.path.expandvars(r"%appdata%\Tencent\WeChat\All Users\config/")+allDir,"r").read()
                    if(os.path.exists(userInstallPath+"\\WeChat Files")):
                        return userInstallPath+"\\WeChat Files"
            return ""
        else:
            return ""
    except Exception,e:
        print e
        return ""

def returnUserList(userInstallPath):
    userList = []
    pathDir = os.listdir(userInstallPath)
    for allDir in pathDir:
        if(allDir != "All Users"):
            userList.append(allDir)
    return userList

def returnUserFileList(userInstallPath,userNumber):
    dirPath = userInstallPath+"\\"+userNumber+"\\CustomEmotions\\"
    pathDir = os.listdir(dirPath)
    fileList = {}
    for allDir in pathDir:
        filePath = dirPath + allDir
        fileData = binascii.b2a_hex(open(filePath,"rb").read())[:2]
        if(fileData == "ff"):
            fileList[filePath] = "jpg"
        elif(fileData == "89"):
            fileList[filePath] = "png"
        elif(fileData == "47"):
            fileList[filePath] = "gif"
        elif(fileData == "42"):
            fileList[filePath] = "bmp"
    return fileList

def exportUserFile(exportPath,exportList):
    if(os.path.exists(exportPath) == False):
        os.makedirs(exportPath)
    for exportData in exportList:
        shutil.copyfile(exportData,exportPath+exportData[exportData.find("CustomEmotions")+len("CustomEmotions"):]+"."+exportList[exportData])

if __name__ == "__main__":
    myPath = isInstallWeChat()
    myUser = returnUserList(myPath)[0]
    exportUserFile(r"C:\Users\Val\Desktop\image",returnUserFileList(myPath,myUser))
